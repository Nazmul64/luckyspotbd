
@include('frontend.pages.header')
   @yield('content')
@include('frontend.pages.footer')
