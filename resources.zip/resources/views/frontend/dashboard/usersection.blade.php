
<section class="inner-banner bg_img" style="background: url('{{ asset('assets/images/inner-banner/bg2.jpg') }}') top;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-xl-6 text-center">
                <h2 class="title text-white">User Dashboard</h2>
                <ul class="breadcrumbs d-flex flex-wrap align-items-center justify-content-center">
                    <li><a href="{{ route('frontend') }}">Home</a></li>
                    <li>Dashboard</li>
                </ul>
            </div>
        </div>
    </div>
</section>


